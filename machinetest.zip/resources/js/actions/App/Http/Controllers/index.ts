import LeadController from './LeadController'
import Settings from './Settings'
const Controllers = {
    LeadController: Object.assign(LeadController, LeadController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers